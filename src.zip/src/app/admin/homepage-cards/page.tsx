"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { isHomepageCardGifUrl, isHomepageCardVideoUrl } from "@/lib/homepage-card-media"
import { Pencil } from "lucide-react"

interface HomepageCard {
  _id: string
  name: string
  tagline?: string
  backgroundUrl?: string
  position: "center" | "bottom-left" | "bottom-right"
  isActive: boolean
  createdAt: string
}

function AdminVideoThumb({ src }: { src: string }) {
  const ref = useRef<HTMLVideoElement>(null)
  return (
    <div
      className="h-full w-full"
      onMouseEnter={() => {
        const video = ref.current
        if (!video) return
        void video.play().catch(() => {
          // Hover can end before play resolves; ignore expected aborts.
        })
      }}
      onMouseLeave={() => {
        const v = ref.current
        if (!v) return
        v.pause()
        v.currentTime = 0
      }}
    >
      <video
        ref={ref}
        src={src}
        className="h-full w-full object-cover"
        muted
        loop
        playsInline
        preload="metadata"
        aria-hidden
      />
    </div>
  )
}

export default function HomepageCardsPage() {
  const [cards, setCards] = useState<HomepageCard[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [uploadingCardId, setUploadingCardId] = useState<string | null>(null)
  const [savingTextCardId, setSavingTextCardId] = useState<string | null>(null)
  const [selectedFiles, setSelectedFiles] = useState<Record<string, File | null>>({})
  const [inputKeys, setInputKeys] = useState<Record<string, number>>({})
  const [editedNames, setEditedNames] = useState<Record<string, string>>({})
  const [editedTaglines, setEditedTaglines] = useState<Record<string, string>>({})

  const fetchCards = useCallback(async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/homepage-cards")
      const data = await response.json()

      if (data.success) {
        setCards(data.data)
        const initialNames: Record<string, string> = {}
        const initialTaglines: Record<string, string> = {}
        for (const card of data.data as HomepageCard[]) {
          initialNames[card._id] = card.name
          initialTaglines[card._id] = card.tagline || ""
        }
        setEditedNames(initialNames)
        setEditedTaglines(initialTaglines)
      }
    } catch (error) {
      console.error("[v0] Error fetching homepage cards:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchCards()
  }, [fetchCards])

  const uploadBackground = async (file: File) => {
    const formData = new FormData()
    formData.append("file", file)

    const uploadResponse = await fetch("/api/admin/homepage-cards/upload", {
      method: "POST",
      body: formData,
    })

    const uploadData = await uploadResponse.json()

    if (!uploadData.success) {
      throw new Error(uploadData.message || "Failed to upload image")
    }

    return uploadData.url as string
  }

  const handleBackgroundReplace = async (cardId: string, file: File) => {
    try {
      setUploadingCardId(cardId)
      setError(null)
      const url = await uploadBackground(file)
      const response = await fetch(`/api/admin/homepage-cards/${cardId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ backgroundUrl: url }),
      })
      const data = await response.json()

      if (data.success) {
        setCards(cards.map((card) => (card._id === cardId ? data.data : card)))
        setSelectedFiles((prev) => ({ ...prev, [cardId]: null }))
        setInputKeys((prev) => ({ ...prev, [cardId]: (prev[cardId] || 0) + 1 }))
        setSuccess("Background updated successfully")
        setTimeout(() => setSuccess(null), 3000)
      } else {
        setError(data.message || "Failed to update background")
      }
    } catch (error: any) {
      console.error("[v0] Error updating homepage card background:", error)
      setError(error.message || "Failed to update background. Please try again.")
    } finally {
      setUploadingCardId(null)
    }
  }

  const handleTextSave = async (cardId: string) => {
    const nextName = (editedNames[cardId] || "").trim()
    const nextTagline = (editedTaglines[cardId] || "").trim()
    if (!nextName) {
      setError("Card name cannot be empty")
      return
    }

    try {
      setSavingTextCardId(cardId)
      setError(null)
      const response = await fetch(`/api/admin/homepage-cards/${cardId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: nextName, tagline: nextTagline }),
      })
      const data = await response.json()

      if (data.success) {
        setCards(cards.map((card) => (card._id === cardId ? data.data : card)))
        setEditedNames((prev) => ({ ...prev, [cardId]: data.data.name }))
        setEditedTaglines((prev) => ({ ...prev, [cardId]: data.data.tagline || "" }))
        setSuccess("Card text updated successfully")
        setTimeout(() => setSuccess(null), 3000)
      } else {
        setError(data.message || "Failed to update card text")
      }
    } catch (saveError: any) {
      console.error("[v0] Error updating homepage card text:", saveError)
      setError(saveError.message || "Failed to update card text. Please try again.")
    } finally {
      setSavingTextCardId(null)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-[#8B5A3C]/10 animate-pulse mx-auto mb-4" />
          <p className="text-foreground">Loading homepage cards...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}
      {success && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
          {success}
        </div>
      )}

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Homepage Cards</h1>
          <p className="text-foreground/60 mt-1">Update card name, tagline, and background media (GIF or MP4)</p>
        </div>
      </div>

      <div className="space-y-3">
        {cards.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border border-[#D9CFC7]">
            <p className="text-foreground/60">No cards found. Please seed the existing cards in the database.</p>
          </div>
        ) : (
          cards.map((card) => (
            <div key={card._id} className="bg-white rounded-lg border border-[#D9CFC7] p-4 transition-all hover:shadow-md">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-md border border-[#EED9C4] bg-[#F9F7F4] flex items-center justify-center text-xs text-foreground/70 overflow-hidden">
                    {card.backgroundUrl && isHomepageCardGifUrl(card.backgroundUrl) ? (
                      <img src={card.backgroundUrl} alt="" className="w-full h-full object-cover" />
                    ) : card.backgroundUrl && isHomepageCardVideoUrl(card.backgroundUrl) ? (
                      <AdminVideoThumb src={card.backgroundUrl} />
                    ) : (
                      "Media"
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">Card</h3>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          card.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {card.isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                    <div className="mt-2 flex flex-col sm:flex-row gap-2 sm:items-center">
                      <div className="relative max-w-sm w-full">
                        <Pencil className="w-4 h-4 text-foreground/50 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <Input
                          value={editedNames[card._id] ?? card.name ?? ""}
                          onChange={(e) => {
                            const value = e.target.value
                            setEditedNames((prev) => ({ ...prev, [card._id]: value }))
                          }}
                          className={`border-[#D9CFC7] text-foreground pl-9 ${
                            ((editedNames[card._id] ?? card.name ?? "").trim() !== (card.name || "").trim())
                              ? "!font-semibold"
                              : "font-normal"
                          }`}
                          disabled={savingTextCardId === card._id}
                          maxLength={100}
                          placeholder="Card name"
                        />
                      </div>
                      <div className="relative max-w-sm w-full">
                        <Pencil className="w-4 h-4 text-foreground/50 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <Input
                          value={editedTaglines[card._id] ?? card.tagline ?? ""}
                          onChange={(e) => {
                            const value = e.target.value
                            setEditedTaglines((prev) => ({ ...prev, [card._id]: value }))
                          }}
                          className={`border-[#D9CFC7] text-foreground pl-9 ${
                            ((editedTaglines[card._id] ?? card.tagline ?? "").trim() !== (card.tagline || "").trim())
                              ? "!font-semibold"
                              : "font-normal"
                          }`}
                          disabled={savingTextCardId === card._id}
                          maxLength={120}
                          placeholder="Card tagline"
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={() => handleTextSave(card._id)}
                        disabled={
                          savingTextCardId === card._id ||
                          (
                            (editedNames[card._id] ?? "").trim() === card.name.trim() &&
                            (editedTaglines[card._id] ?? "").trim() === (card.tagline || "").trim()
                          )
                        }
                        className="bg-[#6D4530] hover:bg-[#4E3222] text-white"
                      >
                        {savingTextCardId === card._id ? "Saving..." : "Save Text"}
                      </Button>
                    </div>
                    <p className="text-sm text-foreground/70">Position: {card.position}</p>
                    <p className="text-xs text-foreground/70">{new Date(card.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>

                <div className="flex flex-col gap-2 md:items-end">
                  <Input
                    key={inputKeys[card._id] || 0}
                    type="file"
                    accept="image/gif,video/mp4,.mp4"
                    className="border-[#D9CFC7] text-foreground"
                    onChange={(e) => {
                      const file = e.target.files?.[0] || null
                      setSelectedFiles((prev) => ({ ...prev, [card._id]: file }))
                    }}
                    disabled={uploadingCardId === card._id}
                  />
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      onClick={() => {
                        const file = selectedFiles[card._id]
                        if (file) {
                          handleBackgroundReplace(card._id, file)
                        }
                      }}
                      disabled={!selectedFiles[card._id] || uploadingCardId === card._id}
                      className="bg-[#6D4530] hover:bg-[#4E3222] text-white"
                    >
                      {uploadingCardId === card._id ? "Uploading..." : "Upload"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setSelectedFiles((prev) => ({ ...prev, [card._id]: null }))
                        setInputKeys((prev) => ({ ...prev, [card._id]: (prev[card._id] || 0) + 1 }))
                      }}
                      disabled={!selectedFiles[card._id] || uploadingCardId === card._id}
                      className="border-[#D9CFC7] text-foreground"
                    >
                      Cancel
                    </Button>
                  </div>
                  <p className="text-xs text-foreground/70">
                    {selectedFiles[card._id] ? "Ready to upload." : "Select a GIF or MP4 to upload."}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
